document.addEventListener('DOMContentLoaded', function () {
    fetch('/check_parking')
        .then(response => response.json())
        .then(data => {
            const distanceElement = document.getElementById('distance');
            const availabilityElement = document.getElementById('availability');

            if (data.error) {
                distanceElement.textContent = 'Error';
                availabilityElement.textContent = data.error;
            } else {
                distanceElement.textContent = data.distance;
                availabilityElement.textContent = data.availability;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
});
