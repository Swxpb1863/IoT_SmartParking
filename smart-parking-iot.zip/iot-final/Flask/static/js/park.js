document.addEventListener("DOMContentLoaded", function () {
    // Assuming parking_status is passed from the Flask backend containing status for each slot
     var parkingStatus = {
            "Slot 1": "Occupied", // Replace with values from your database
            "Slot 2": "Vacant",   // Replace with values from your database
            "Slot 3": "Occupied", // Replace with values from your database
            "Slot 4": "Vacant"    // Replace with values from your database
        };

    Object.keys(parkingStatus).forEach(function (slot) {
        var element = document.getElementById(slot.toLowerCase().replace(" ", ""));
        if (parkingStatus[slot] === "Occupied") {
            element.classList.add("occupied");
        } else {
            element.classList.add("vacant");
        }
    });
});
