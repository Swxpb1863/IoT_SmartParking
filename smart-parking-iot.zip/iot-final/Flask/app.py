from flask import *
import ibm_db as ibm

app = Flask(__name__)
app.secret_key = "this is very confidential"

connection = ibm.connect(
    "DATABASE=bludb;HOSTNAME=55fbc997-9266-4331-afd3-888b05e734c0.bs2io90l08kqb1od8lcg.databases.appdomain.cloud;PORT=31929;SECURITY=SSL;SSLServerCertificate=DigiCertGlobalRootCA.crt;UID=qhp77202;PWD=xKDt1Nphp7i1BGAl;",
    "", "")

print("CONNECTED!")


@app.route('/')
def index():
    return render_template('index.html')



@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['email']
        password = request.form['password']

        if connection:
            query = "INSERT INTO register (email, password) VALUES (?, ?)"
            stmt = ibm.prepare(connection, query)
            ibm.bind_param(stmt, 1, username)
            ibm.bind_param(stmt, 2, password)
            result = ibm.fetch_assoc(stmt)
            ibm_db.close(connection)

            if result:
                flash('Registration successful!', 'success')
                return render_template('login.html')
            else:
                flash('Registration failed. Please try again.', 'error')
        else:
            flash('Failed to connect to the IBM Db2 Cloud database.', 'error')

    return render_template('register.html')


@app.route('/index', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['email']
        password = request.form['password']

        if connection:
            query = "SELECT * FROM REGISTER WHERE EMAIL = ? AND PASSWORD = ?"
            stmt = ibm.prepare(connection, query)
            result = ibm.execute(stmt, (username, password))
            user = ibm.fetch_assoc(stmt)

            if user:
                session['user_id'] = user['EMAIL']
                flash('Login successful!', 'success')
                return render_template('dashboard.html')
            else:
                flash('Login failed. Please check your credentials.', 'error')
        else:
            flash('Failed to connect to the IBM Db2 Cloud database.', 'error')

    return render_template('login.html')


@app.route('/parking_availability', methods=['GET'])
def parking_availability():
    if connection:
        try:
            query = "SELECT slot_1, slot_2, slot_3, slot_4 FROM availability"
            stmt = ibm.exec_immediate(connection, query)
            result = ibm.fetch_assoc(stmt)
            if result:
                slot_1 = result['SLOT_1']
                slot_2 = result['SLOT_2']
                slot_3 = result['SLOT_3']
                slot_4 = result['SLOT_4']

                parking_status = {
                    "Slot 1": "Occupied" if slot_1 == 1 else "Vacant",
                    "Slot 2": "Occupied" if slot_2 == 1 else "Vacant",
                    "Slot 3": "Occupied" if slot_3 == 1 else "Vacant",
                    "Slot 4": "Occupied" if slot_4 == 1 else "Vacant",
                }

                flash('Parking availability:', 'success')
                return render_template('dashboard.html', parking_status=parking_status)
                print("Availability fetched")
            else:
                flash('No data found in the availability table.', 'error')
        except Exception as e:
            flash(f'Error: {str(e)}', 'error')
    else:
        flash('Failed to connect to the IBM Db2 Cloud database.', 'error')

    return render_template('dashboard.html')


if __name__ == "__main__":
    app.run(debug=True)

